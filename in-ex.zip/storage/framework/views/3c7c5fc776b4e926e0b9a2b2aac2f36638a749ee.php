<?php $__env->startSection('title'); ?>
Expenes Types
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title"><div class="input-group input-group-sm" style="width: 150px;">
                    <div class="input-group-btn">
                            <a href="/dashboard/expenes-types/add" class="btn btn-block btn-primary">Create New</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                        <tr>
                            <th>Date</th>
                            <th>Expenes Type</th>
                            <th>Note</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $expenes_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenes_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($expenes_type->created_at); ?></td>
                            <td><?php echo e($expenes_type->type); ?></td>
                            <td><?php echo e($expenes_type->note); ?></td>
                            <td>
                                <a href="/dashboard/expenes-types/edit/<?php echo e($expenes_type->id); ?>" class="text-primary">Edit</a>
                                 | 
                                <a class="btnDelete text-danger" data-url="/dashboard/expenes-types/delete/<?php echo e($expenes_type->id); ?>" href="javascript:void(0)" >Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>