<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php echo $__env->make('elements.style-on-head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('custom-style'); ?>
</head>

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('elements.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('elements.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content-wrapper">
        <?php echo $__env->yieldContent('flashMessage'); ?>
            <?php if(session('flashMessage')): ?>
                <section id="flashMessage">
                    <div class="alert alert-<?php echo e(session('flashMessage')['status']); ?>" style="margin-bottom: 0;">
                        <span><?php echo e(session('flashMessage')['message']); ?></span>
                        <i class="fa fa-close close-msg"></i>
                    </div>
                </section>
            <?php endif; ?>
            <section class="content-header">
                <h1><?php echo $__env->yieldContent('title'); ?></h1>
            </section>
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
        <?php echo $__env->make('elements.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('elements.right-side-setting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php echo $__env->make('elements.script-below-body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('custom-script'); ?>
</body>

</html>
