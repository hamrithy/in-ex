<?php $__env->startSection('title'); ?>
Create Expenes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Create Expenes</h3>
    </div>
    <?php echo e(Form::open(['url'=>'/dashboard/expenes/add','method'=>'post'])); ?>

        <div class="box-body">
            <div class="form-group <?php if($errors->has('date')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('date','Revenue Date')); ?>

                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <?php echo e(Form::text('date',old('date'),['class'=>'form-control','placeholder'=>'Select date'])); ?>

                    <?php if($errors->has('date')): ?>
                        <span class="help-block"><?php echo e($errors->first('date')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group <?php if($errors->has('reference_no')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('reference_no','Reference No')); ?>

                <?php echo e(Form::text('reference_no',old('reference_no'),['class'=>'form-control','placeholder'=>'Enter reference no'])); ?>

                <?php if($errors->has('reference_no')): ?>
	                <span class="help-block"><?php echo e($errors->first('reference_no')); ?></span>
	            <?php endif; ?>
            </div>
            <div class="form-group <?php if($errors->has('expenes_type_id')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('expenes_type_id','Expenes Type')); ?>

                <?php echo e(Form::select('expenes_type_id',$expenes_types,old('expenes_type_id'),['class'=>'form-control','placeholder'=>'Select expenes type'])); ?>

                <?php if($errors->has('expenes_type_id')): ?>
                    <span class="help-block"><?php echo e($errors->first('expenes_type_id')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php if($errors->has('currency')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('currency','Currency')); ?>

                <?php echo e(Form::select('currency',$currencies,old('currency'),['class'=>'form-control','placeholder'=>'Select currency'])); ?>

                <?php if($errors->has('currency')): ?>
                    <span class="help-block"><?php echo e($errors->first('currency')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php if($errors->has('price')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('price','Expenes Price')); ?>

                <?php echo e(Form::text('price',old('price'),['class'=>'form-control','placeholder'=>'Enter expenes price'])); ?>

                <?php if($errors->has('price')): ?>
                    <span class="help-block"><?php echo e($errors->first('price')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php if($errors->has('exchange_rate')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('exchange_rate','Price\'s Exchange Rate')); ?>

                <?php echo e(Form::number('exchange_rate',old('exchange_rate'),['class'=>'form-control','placeholder'=>'Exchange rate in 1 USD', 'step'=>'any'])); ?>

                <?php if($errors->has('exchange_rate')): ?>
                    <span class="help-block"><?php echo e($errors->first('exchange_rate')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="box-footer">
            <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

        </div>
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
<script>
    $("#date").datepicker({ 
        format: 'yyyy-mm-dd'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>