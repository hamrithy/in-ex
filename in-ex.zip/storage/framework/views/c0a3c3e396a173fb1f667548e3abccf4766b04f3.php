<?php $__env->startSection('title'); ?>
Update Expenes Type
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Update Expenes Type</h3>
    </div>
    <?php echo e(Form::model($expenes_type,['url'=>'/dashboard/expenes-types/edit/'.$expenes_type->id,'method'=>'post'])); ?>

        <div class="box-body">
            <div class="form-group <?php if($errors->has('type')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('type','Expenes Type')); ?>

                <?php echo e(Form::text('type',old('type'),['class'=>'form-control','placeholder'=>'Enter currency type'])); ?>

                <?php if($errors->has('type')): ?>
	                <span class="help-block"><?php echo e($errors->first('type')); ?></span>
	            <?php endif; ?>
            </div>
            <div class="form-group <?php if($errors->has('note')): ?> has-error <?php endif; ?>">
                <?php echo e(Form::label('note','Note')); ?>

                <?php echo e(Form::textarea('note',old('note'),['rows'=>5,'class'=>'form-control','placeholder'=>'Enter currency note'])); ?>

                <?php if($errors->has('note')): ?>
	                <span class="help-block"><?php echo e($errors->first('note')); ?></span>
	            <?php endif; ?>
            </div>
        </div>
        <div class="box-footer">
            <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

        </div>
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>