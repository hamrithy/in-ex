<div class="box box-primary">
    <div class="box-body table-responsive no-padding">
        <table class="table">
            <tr>
                <th><h4 class="box-title"><b>Revenues</b></h4></th>
            </tr>
            <tr>
                <th>Date</th>
                <th>Reference No</th>
                <th>Expenes Type</th>
                <th>Price</th>
                <th>Exchange rate</th>
                <th>Total</th>
            </tr>
            <?php $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($revenue->created_at); ?></td>
                <td><?php echo e($revenue->reference_no); ?></td>
                <td><?php echo e($revenue->revenue_type->type); ?></td>
                <td><?php echo e($revenue->currency); ?> <?php echo e(number_format($revenue->price, 2, '.', ',')); ?></td>
                <td><?php echo e($revenue->currency); ?> <?php echo e(number_format($revenue->exchange_rate, 2, '.', ',')); ?></td>
                <td>USD <?php echo e(number_format($revenue->total, 2, '.', ',')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td class="alert alert-success"><b>GRAND TOTAL:</b></td>
                <td class="alert alert-success"><b>USD <?php echo e(number_format($totalRevenue, 2, '.', ',')); ?></b></td>
            </tr>
            <tr>
                <th><h4 class="box-title"><b>Expenes</b></h4></th>
            </tr>
            <tr>
                <th>Date</th>
                <th>Reference No</th>
                <th>Expenes Type</th>
                <th>Price</th>
                <th>Exchange rate</th>
                <th>Total</th>
            </tr>
            <?php $__currentLoopData = $expenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expene): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($expene->created_at); ?></td>
                <td><?php echo e($expene->reference_no); ?></td>
                <td><?php echo e($expene->expenes_type->type); ?></td>
                <td><?php echo e($expene->currency); ?> <?php echo e(number_format($expene->price, 2, '.', ',')); ?></td>
                <td><?php echo e($expene->currency); ?> <?php echo e(number_format($expene->exchange_rate, 2, '.', ',')); ?></td>
                <td>USD <?php echo e(number_format($expene->total, 2, '.', ',')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td class="alert alert-danger"><b>GRAND TOTAL:</b></td>
                <td class="alert alert-danger"><b>USD <?php echo e(number_format($totalExpenes, 2, '.', ',')); ?></b></td>
            </tr>
            <tr>
                <th><h4><b>Incomes</b></h4></th>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td class="alert alert-info"><b>NET INCOME:</b></td>
                <td class="alert alert-info"><b>USD <?php echo e(number_format($totalRevenue-$totalExpenes, 2, '.', ',')); ?></b></td> 
            </tr>
        </table>
    </div>
</div>
<script>
    $('#netIncome').val(<?php echo e($totalRevenue-$totalExpenes); ?>);
</script>