<?php $__env->startSection('title'); ?>
Revenues
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title"><div class="input-group input-group-sm" style="width: 150px;">
                    <div class="input-group-btn">
                            <a href="/dashboard/revenues/add" class="btn btn-block btn-primary">Create New</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                        <tr>
                            <th>Date</th>
                            <th>Reference No</th>
                            <th>Revenue Type</th>
                            <th>Price</th>
                            <th>Exchange rate</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($revenue->date); ?></td>
                            <td><?php echo e($revenue->reference_no); ?></td>
                            <td><?php echo e($revenue->revenue_type->type); ?></td>
                            <td><?php echo e($revenue->currency); ?> <?php echo e(number_format($revenue->price, 2, '.', ',')); ?></td>
                            <td><?php echo e($revenue->currency); ?> <?php echo e(number_format($revenue->exchange_rate, 2, '.', ',')); ?></td>
                            <td>USD <?php echo e(number_format($revenue->total, 2, '.', ',')); ?></td>
                            <td>
                                <a href="/dashboard/revenues/edit/<?php echo e($revenue->id); ?>" class="text-primary">Edit</a>
                                 | 
                                <a class="btnDelete text-danger" data-url="/dashboard/revenues/delete/<?php echo e($revenue->id); ?>" href="javascript:void(0)" >Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>