<?php $__env->startSection('title'); ?>
Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="login">
    <h1>User Login</h1>
    <?php echo e(Form::open(['url'=>'/login'])); ?>

    <form accept-charset="UTF-8" action="http://bunong.dev:81/users/login" method="POST">
        <div class="input text">
            <input type="text" id="username" value="<?php echo e(old('username')); ?>" autofocus="autofocus" name="username" required="required" placeholder="Enter your username">
            <?php if($errors->has('username')): ?>
                <span class="form-msg"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
        </div>
        <div class="input password">
            <input type="password" id="password" value="" name="password" required="required" placeholder="Enter your password">
            <?php if($errors->has('password')): ?>
                <span class="form-msg"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>
        <div class="input submit">
            <?php echo e(Form::submit('Login')); ?>

        </div>
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>